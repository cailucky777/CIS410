
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkDataSetReader.h>
#include <vtkDataSetMapper.h>
#include <vtkActor.h>
#include <vtkLookupTable.h>
#include <vtkCamera.h>
#include <vtkContourFilter.h>
#include <vtkDataSetWriter.h>
#include <vtkCutter.h>
#include <vtkPlane.h>
#include <vtkNew.h>


int main(int argc, char *argv[])
{
   vtkDataSetReader *reader = vtkDataSetReader::New();
   reader->SetFileName("noise.vtk");
   reader->Update();
   
   //Contour the data.
   vtkContourFilter *cf = vtkContourFilter::New();
   cf->SetNumberOfContours(2);
   cf->SetValue(0,2.4);
   cf->SetValue(1, 4);
   cf->SetInputConnection(reader->GetOutputPort());
   
   
   //slice by Z= 0
   vtkNew<vtkPlane> Plane;
   Plane->SetOrigin(0.0,0.0,0.0);
   Plane->SetNormal(0.0,0.0,1.0);
   
   vtkNew<vtkCutter> Cutter;
   Cutter->SetCutFunction(Plane);
   Cutter->SetInputConnection(reader->GetOutputPort());
   
   
   //to geometric primitives
   vtkDataSetMapper *mapper = vtkDataSetMapper::New();
   mapper->SetInputConnection(Cutter->GetOutputPort());
   
   //maps data to geometric primitives
   vtkDataSetMapper *cfmapper = vtkDataSetMapper::New();
   cfmapper->SetInputConnection(cf->GetOutputPort());
   
   vtkLookupTable *lut = vtkLookupTable::New();
   //SetTableValue (vtkIdType indx, double r, double g, double b, double a=1.0)
   //Set the color for each of these 256 entries, manually interpolating
   //from blue to red. blue(0,0,255)->red(255,0,0)
   for(int i=0; i<256; i++){
      lut->SetTableValue(i,i,0.0,(255.0-i),1.0);
   }
   mapper->SetLookupTable(lut);
   mapper->SetScalarRange(1,6);
   cfmapper->SetLookupTable(lut);
   cfmapper->SetScalarRange(1,6);
   lut->Build();
   
   //something that can be placed into a renderer
   vtkActor *actor = vtkActor::New();
   actor->SetMapper(mapper);

   vtkActor *cfactor = vtkActor::New();
   cfactor->SetMapper(cfmapper);
   
   vtkRenderer *ren = vtkRenderer::New();
   ren->AddActor(actor);
   ren->AddActor(cfactor);

   vtkRenderWindow *renwin = vtkRenderWindow::New();
   renwin->AddRenderer(ren);
   renwin->SetSize(768,768);

   //defines what button clicks, mouse movements, etc. should do
   vtkRenderWindowInteractor *iren = vtkRenderWindowInteractor::New();
   iren->SetRenderWindow(renwin);
   renwin->Render();
   iren->Start();
}


